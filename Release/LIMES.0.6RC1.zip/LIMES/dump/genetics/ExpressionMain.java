package de.uni_leipzig.simba.genetics;

import java.util.LinkedList;
import java.util.List;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.GPProblem;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.GPGenotype;
import org.jgap.gp.impl.ProgramChromosome;

import de.uni_leipzig.simba.genetics.core.*;

/**
 * Class Runs JGAP.
 * @author Klaus Lyko
 *
 */
public class ExpressionMain {
	
	
	public static void run() throws InvalidConfigurationException {
		ExpressionConfiguration config = new ExpressionConfiguration("PublicationData.xml");
		config.setUpTestCase();
		

		//population size
		config.setPopulationSize(50);
		GPProblem gpP = new ExpressionProblem(config);
		GPGenotype gp = gpP.create();
		List<String> bestSolutions = new LinkedList<String>();
		for(int gen=0; gen<10; gen++) {
			gp.evolve(1);
			IGPProgram gProg =  gp.getFittestProgram();
			Object[] args = {};
			ProgramChromosome pc = gProg.getChromosome(0);
			String expr =(String) pc.getNode(0).execute_object(pc, 0, args);
			double d = gProg.getChromosome(1).execute_double(args);
			String out = "Fittest Program : "+expr+" >= "+d+"\n\t"+gProg.getFitnessValue();
			System.out.println(out);
			bestSolutions.add(out);
		}
		
		for(String a : bestSolutions) {
			System.out.println(a);
		}
	}
	

	/**
	 * TerminalType help to differentiate resources of source and target.
	 * @author Klaus Lyko
	 */
	public enum ResourceTerminalType {
		SOURCE(1),
		TARGET(2), 
		THRESHOLD(3), ;
		private int m_value;
		public int intValue() {
			return m_value;
		}
		ResourceTerminalType (int a_value) {
			m_value = a_value;
		}
		
	}
	
	public static void main(String args[]) throws InvalidConfigurationException{
		run();
	}
}
