package de.uni_leipzig.simba.genetics;

import java.util.HashMap;

import de.uni_leipzig.simba.cache.HybridCache;
import de.uni_leipzig.simba.data.Mapping;
import de.uni_leipzig.simba.filter.Filter;
import de.uni_leipzig.simba.filter.LinearFilter;
import de.uni_leipzig.simba.io.ConfigReader;
import de.uni_leipzig.simba.learning.learner.PerceptronLearner;
import de.uni_leipzig.simba.learning.oracle.oracle.Oracle;
import de.uni_leipzig.simba.learning.oracle.oracle.OracleFactory;
import de.uni_leipzig.simba.mapper.SetConstraintsMapper;
import de.uni_leipzig.simba.mapper.SetConstraintsMapperFactory;
import de.uni_leipzig.simba.mapper.algorithms.PPJoinPlusPlus;
import de.uni_leipzig.simba.mapper.atomic.PPJoinMapper;

public class LearnerTester {
	
	public void act() {
		// read Config
		String configFile = "PublicationData.xml";
		ConfigReader cR = new ConfigReader();
		cR.validateAndRead(configFile);
		
		// create Caches
		HybridCache sC = HybridCache.getData(cR.getSourceInfo());
		HybridCache tC = HybridCache.getData(cR.targetInfo);
		
		// get Oracle
		String file = "C:/Users/Lyko/Desktop/Ba Arbeit/DBLP-ACM/DBLP-ACM/DBLP-ACM_perfectMapping.csv";
		Oracle o = OracleFactory.getOracle(file, "csv", "simple");
		
		//PropertyMapping
        Mapping m = new Mapping();
        m.add("title",
                "title",
                9.0);
        HashMap<String, String> hM= new HashMap<String, String>();
        hM.put("title", "string");
        hM.put("authors", "string");
    
		
		PerceptronLearner pL = new PerceptronLearner(cR.sourceInfo, cR.targetInfo, sC, tC,
				o, m, hM, 0.5, 0.5);
		
		pL.computeNextConfig(1);
	}
	
	public void testPPJoin() {
		// read Config
		String configFile = "PublicationData.xml";
		ConfigReader cR = new ConfigReader();
		cR.validateAndRead(configFile);
		
		// create Caches
		HybridCache sC = HybridCache.getData(cR.getSourceInfo());
		HybridCache tC = HybridCache.getData(cR.targetInfo);
		
		SetConstraintsMapper mapper = SetConstraintsMapperFactory.getMapper("simple", cR.targetInfo,
	                cR.sourceInfo, tC, sC, new LinearFilter(), 2);
		Mapping results = mapper.getLinks("trigrams(x.title, y.title)", 0.9);
		//PPJoinMapper ppM = new PPJoinMapper();
		//ppM.getMapping(sC, tC, cR.sourceInfo.var, cR.targetInfo.var, "cosine(x.title, y.title)|0.8", 0.8);
	}
	
	public static void main(String[] args) {
		LearnerTester lT = new LearnerTester();
		lT.testPPJoin();
	}
}
