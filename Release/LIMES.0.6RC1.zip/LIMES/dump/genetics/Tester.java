package de.uni_leipzig.simba.genetics;

import java.util.HashMap;

import org.apache.log4j.Logger;

import de.uni_leipzig.simba.cache.HybridCache;
import de.uni_leipzig.simba.controller.PPJoinController;
import de.uni_leipzig.simba.data.Mapping;
import de.uni_leipzig.simba.evaluation.PRFComputer;
import de.uni_leipzig.simba.filter.Filter;
import de.uni_leipzig.simba.filter.LinearFilter;
import de.uni_leipzig.simba.io.ConfigReader;
import de.uni_leipzig.simba.io.KBInfo;
import de.uni_leipzig.simba.learning.oracle.oracle.Oracle;
import de.uni_leipzig.simba.learning.oracle.oracle.OracleFactory;
import de.uni_leipzig.simba.mapper.SetConstraintsMapper;
import de.uni_leipzig.simba.mapper.SetConstraintsMapperFactory;
import de.uni_leipzig.simba.metricfactory.ComplexMetricFactory;
import de.uni_leipzig.simba.metricfactory.MetricFactory;
import de.uni_leipzig.simba.metricfactory.SimpleMetricFactory;

public class Tester {
	static Logger log = Logger.getLogger("LIMES");
	
	public static void main(String args[]) {

		readConfigProperties();
		System.exit(1);
		// read Config
		String configFile = "PublicationData.xml";
		ConfigReader cR = new ConfigReader();
		cR.validateAndRead(configFile);
		
		// create Caches
		
		HybridCache sC = HybridCache.getData(cR.getSourceInfo());
	
		HybridCache tC = HybridCache.getData(cR.targetInfo);
		Filter f = new LinearFilter();
		// call Mapper
		SetConstraintsMapper sCM = SetConstraintsMapperFactory.getMapper("filterbased", 
				cR.sourceInfo, cR.targetInfo, 
				sC, tC, f, cR.granularity);
		
		Mapping actualMapping = f.filter(sCM.getLinks(cR.metricExpression, cR.acceptanceThreshold), cR.acceptanceThreshold);
		
		//try reading into oracle
		String file = "C:/Users/Lyko/Desktop/Ba Arbeit/DBLP-ACM/DBLP-ACM/DBLP-ACM_perfectMapping.csv";
		Oracle o = OracleFactory.getOracle(file, "csv", "simple");
		Mapping optimalMapping = o.getMapping();
		o.loadData(optimalMapping);
		//System.out.println(m);
		/*
		boolean b;
		HashMap<String, HashMap<String, Double>> map = m.map;
		b = o.ask("conf/sigmod/PolyzotisG02", "564733");
		log.info(b);
		*/
	//	log.info(actualMapping);
	//	log.info("------------");
	//	log.info(optimalMapping);
		log.info("Found "+actualMapping.size()+" links out of "+optimalMapping.size());
		
		PRFComputer prfC = new PRFComputer();
		double fScore = prfC.computeFScore(actualMapping, optimalMapping);
		
		log.info("F-Score = "+fScore);
	}
	
	
	public static void readConfigProperties() {
		String configFile = "PublicationData.xml";
		ConfigReader cR = new ConfigReader();
		cR.validateAndRead(configFile);
		
		KBInfo source = cR.getSourceInfo();
		String prefix = source.var;
		if(prefix.startsWith("?") && prefix.length()>=2)
			prefix=prefix.substring(1);
		
		
		for(String prop : source.properties) {
			System.out.println(prefix+"."+prop);
		}
		
		
	}
}
