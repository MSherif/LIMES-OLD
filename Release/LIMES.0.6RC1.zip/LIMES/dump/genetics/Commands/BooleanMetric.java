package de.uni_leipzig.simba.genetics.Commands;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.ProgramChromosome;

import de.uni_leipzig.simba.genetics.ExpressionMain.ResourceTerminalType;

/**
 * Wraps around boolean LIMES commands such as OR and AND.
 * @author Klaus Lyko
 *
 */
public class BooleanMetric extends CommandGene {

	
	/**
	 * Basic Constructor.
	 * @param a_conf a_conf A JGAP GPconfiguration instance.
	 * @throws InvalidConfigurationException
	 */
	public BooleanMetric(final GPConfiguration a_conf) 
	throws InvalidConfigurationException {
		this(a_conf, String.class);
	}
	/**
	 * Default Constructor. A Boolean Metric is a boolean expression combining two
	 * similarity measures as of now.
	 * @TODO For a future version also allow other boolean measures to be children of this node.
	 * @param a_conf A JGAP GPconfiguration instance.
	 * @param a_returnType Define the return type of this node.
	 * @throws InvalidConfigurationException
	 */
	public BooleanMetric(final GPConfiguration a_conf, Class a_returnType)
	throws InvalidConfigurationException {
		super(a_conf, 2, a_returnType, 0,
				new int[]{1, 1}
			);
	}
	
	@Override
	public Class getChildType(IGPProgram a_ind, int a_chromNum) {
		return String.class;
	}
	
	@Override
	public String toString() {
		return "BOOLEAN_EXPRESSION(sim1, sim2)";
	}
	
	/**
	 * Executes AndCommand as and Object returning String of resulting expression.
	 */
	public Object execute_object(ProgramChromosome a_chrom, int a_n, Object[] args, String booleanCommand) {
		StringBuffer value = new StringBuffer(booleanCommand);
		value.append("(");
		value.append( a_chrom.execute_object(a_n, 0, args));
		value.append(",");
		value.append( a_chrom.execute_object(a_n, 1, args));
		value.append(")");
		return value.toString();
	}

}
