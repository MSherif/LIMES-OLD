package de.uni_leipzig.simba.genetics.Commands;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.IMutateable;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.ProgramChromosome;

import de.uni_leipzig.simba.genetics.core.ExpressionConfiguration;

public class OrCommand extends BooleanMetric 
implements IMutateable {
	
	public OrCommand(GPConfiguration a_conf) throws InvalidConfigurationException {
		super(a_conf);
	}
	
	public OrCommand(GPConfiguration a_conf, Class a_returnType) throws InvalidConfigurationException {
		super(a_conf, a_returnType);
	}

	@Override
	public CommandGene applyMutation(int a_index, double a_percentage)
			throws InvalidConfigurationException {
		return this;
	}
	
	@Override
	public String toString() {
		return "OR(&1, &2)";
	}
	
	/**
	 * Executes AndCommand as and Object returning String of resulting expression.
	 */
	public Object execute_object(ProgramChromosome a_chrom, int a_n, Object[] args) {
		return execute_object(a_chrom, a_n, args, "OR");
	}
	
	public void execute_void(ProgramChromosome a_chrom, int a_n, Object[] args) {
		execute_object(a_chrom, a_n, args);
	}

}
