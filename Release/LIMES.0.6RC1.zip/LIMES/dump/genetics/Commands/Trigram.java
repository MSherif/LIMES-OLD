package de.uni_leipzig.simba.genetics.Commands;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.IMutateable;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.ProgramChromosome;

import de.uni_leipzig.simba.genetics.core.ExpressionConfiguration;

public class Trigram extends SimilarityCommand 
implements IMutateable{

	public Trigram(GPConfiguration a_conf, Class a_returnType)
			throws InvalidConfigurationException {
		super("trigram", a_conf, a_returnType, true);
	}
	
	public Trigram(GPConfiguration a_conf, Class a_returnType, int a_subReturnType) throws InvalidConfigurationException {
		super("trigram", a_conf, a_returnType, a_subReturnType, true);
	}

	public String toString() {
		return "trigrams(&1, &2)|&3";
	}
	
	public String getName() {
		return "Trigram";
	}
	
	@Override
	public String getOperationName() {
		return "trigram";
	}

	@Override
	public CommandGene applyMutation(int a_index, double a_percentage)
			throws InvalidConfigurationException {
		// TODO Auto-generated method stub
		return null;
	}
	
}
