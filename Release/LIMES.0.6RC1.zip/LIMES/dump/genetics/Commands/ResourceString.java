package de.uni_leipzig.simba.genetics.Commands;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.IMutateable;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.ProgramChromosome;
import org.jgap.gp.terminal.Terminal;
import org.jgap.util.CloneException;
import org.jgap.util.ICloneable;

/**
 * An Implementation of a Terminal, representing our resources. 
 * It is basically a String Terminal.
 * @TODO We should support two different sets of Resources: 
 * those from the source and those from the target.
 * @author Klaus Lyko
 *
 */
public class ResourceString extends Terminal 
implements IMutateable, ICloneable {

	private String value = "";
	
	public ResourceString(GPConfiguration a_config) 
	throws InvalidConfigurationException {
		super(a_config, String.class);
	}
	
	public ResourceString(GPConfiguration a_config, String a_value) 
	throws InvalidConfigurationException {
		this(a_config);
		value = a_value;
	}
	
	public void setValue(String resource) {
		value = resource;
	}
	@Override
	public String toString() {
		return value;
	}
	 
	 @Override
	  public Object execute_object(ProgramChromosome c, int n, Object[] args) {
		 StringBuffer value = new StringBuffer(this.value);
//	     StringBuffer value = new StringBuffer("(");
//	     Class retType = getReturnType();
//	     if (retType == String.class) {
//	       value.append(value);//.append("S");
//	     }
//	     value.append(")");
		 return value;
	  }

	 @Override
	  public Class getChildType(IGPProgram a_ind, int a_chromNum) {
	    return null;
	  }

	  @Override
	  public Object clone() {
	    try {
	      ResourceString result = new ResourceString(getGPConfiguration());
	      result.setValue(value);
	      return result;
	    } catch (Throwable t) {
	      throw new CloneException(t);
	    }
	  }
	  @Override
	  public CommandGene applyMutation(int index, double a_percentage)
      throws InvalidConfigurationException {
		  //TODO As of now we don't mutate
		  return this;
	  }
	  
	  @Override
	  public void setRandomValue() {
		  Class retType = getReturnType();
		  if(retType == String.class) {
			  //TODO randomly set a valid resource
			  setRandomValue("a.title");
		  }
		  else {
			  throw new RuntimeException("unknown terminal type: " + retType);
		  }
	  }
	  
	  public void setRandomValue(String a_value) {
		  this.value=a_value;
	  }
	  
	  public String getName() {
		  return "ResourceString";
	  }

}
