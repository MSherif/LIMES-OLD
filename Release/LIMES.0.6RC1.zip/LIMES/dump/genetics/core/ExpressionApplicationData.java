package de.uni_leipzig.simba.genetics.core;

import org.jgap.IApplicationData;
/**
 * Class holding additional data for the evolution of LIMES configurations.
 * @author Klaus Lyko
 *
 */
public class ExpressionApplicationData implements IApplicationData
{
	/**
	 * Path to the LIMES configuration file.
	 */
	public String configFile;
	
	/**
	 * Boundaries for Acceptance and Review thresholds.
	 * @TODO make sure maxRev<current AccThreshold
	 */
	public static final double minAcc=0.8d, maxAcc=1.0d,
		minRev=0.7d, maxRev=0.9d;
	
	
	
	public ExpressionApplicationData(String configFilePath) {
		super();
		configFile=configFilePath;
	}
	/* What additional application data do we need?
	 * - Chaches / Mapping with the reference data
	 * - basic boundaries for thresholds to limit computational time
	 */
	

	@Override
	public int compareTo(Object o) {
		if(o.getClass().equals(this.getClass())) {
			return 0;
		}
		return 1;
	}
	
	public Object clone() {
		return new ExpressionApplicationData(configFile);
	}
	
	public double getMinAcc() {
		return minAcc;
	}
	
	public double getMaxRev() {
		return maxRev;
	}
}
