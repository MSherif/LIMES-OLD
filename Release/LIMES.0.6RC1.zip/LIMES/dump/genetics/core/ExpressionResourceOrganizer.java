package de.uni_leipzig.simba.genetics.core;
/**
 * Wraps around all possible resources of a given Mapping between source and target.
 * @author Klaus Lyko
 *
 */
public class ExpressionResourceOrganizer {
	private String[] sourceResources;
	private String[] targetResources;
	
	public ExpressionResourceOrganizer (String[] source, String[] target) {
		sourceResources = source;
		targetResources = target;
	}
	
	public String getSource(int pos) {
		return sourceResources[pos];
	}
	
	public String getTarget(int pos) {
		return targetResources[pos];
	}
}
