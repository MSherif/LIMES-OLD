package de.uni_leipzig.simba.genetics.core;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.GPProblem;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.GPGenotype;
import org.jgap.gp.terminal.Terminal;

import de.uni_leipzig.simba.genetics.Commands.AndCommand;
import de.uni_leipzig.simba.genetics.Commands.OrCommand;
import de.uni_leipzig.simba.genetics.Commands.SimilarityCommand;
import de.uni_leipzig.simba.genetics.ExpressionMain.ResourceTerminalType;

public class ExpressionProblem extends GPProblem{


	  public ExpressionProblem(GPConfiguration a_conf)
	      throws InvalidConfigurationException {
	    super(a_conf);
	  }
	
	@Override
	public GPGenotype create() throws InvalidConfigurationException {
		  ExpressionConfiguration config = (ExpressionConfiguration) getGPConfiguration();
			//	ExpressionApplicationData applData = new ExpressionApplicationData("PublicationData.xml");
				
				// a program has two chromosomes: first an expression, second a acceptance threshold 
				Class[] types = {String.class, CommandGene.DoubleClass};
				Class[][] argTypes = {{
				}, {}
				};
				
				CommandGene[][] nodeSets = {
						{	
							// Terminal representing source properties
							new Terminal(config, CommandGene.IntegerClass, 0,
				                     config.source.properties.size()-1, true,
				                     ResourceTerminalType.SOURCE.intValue()),
				            // Terminal representing target properties
				            new Terminal(config, CommandGene.IntegerClass, 0,
						             config.target.properties.size()-1, true,
						             ResourceTerminalType.TARGET.intValue()),
						    // threshold for SimilarityCommands
						    new Terminal(config, CommandGene.DoubleClass, 0.5d, 1.0d, false, 
						    		ResourceTerminalType.THRESHOLD.intValue()),
						 
						    new SimilarityCommand("trigram", config, String.class, 1, true),
						    new SimilarityCommand("cosine", config, String.class, 1, true),
						    new SimilarityCommand("jaccard", config, String.class, 1, true),
						//    new SimilarityCommand("euclidean", config, String.class, 1, true),
						    new AndCommand(config, String.class),
						   
						    new OrCommand(config, String.class),
						},
						{// acceptanceThreshold
							new Terminal(config, CommandGene.DoubleClass, 0.8d, 1.0d, false, 0, true),
						}
				};
				int[] minDepths= new int[2];
				int[] maxDepths = new int[2];
				minDepths[0] = 0;
				minDepths[1] = 0;
				maxDepths[0] = 4;
				maxDepths[1] = 1;
				//@TODO why do i have to turn it of???
				boolean[] fullModeAllowed= {false, false};
				
				return GPGenotype.randomInitialGenotype(config,
					      types, argTypes, nodeSets,
					      minDepths, maxDepths, 12, fullModeAllowed,
					      false);
	}

}
