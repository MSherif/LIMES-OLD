package de.uni_leipzig.simba.genetics.core;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.jgap.gp.CommandGene;
import org.jgap.gp.GPFitnessFunction;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.impl.ProgramChromosome;
import org.apache.log4j.Logger;
import de.uni_leipzig.simba.cache.HybridCache;

import de.uni_leipzig.simba.data.Mapping;
import de.uni_leipzig.simba.evaluation.PRFComputer;
import de.uni_leipzig.simba.filter.Filter;
import de.uni_leipzig.simba.filter.LinearFilter;
import de.uni_leipzig.simba.genetics.ExpressionMain.ResourceTerminalType;
import de.uni_leipzig.simba.io.ConfigReader;
import de.uni_leipzig.simba.learning.oracle.oracle.Oracle;
import de.uni_leipzig.simba.learning.oracle.oracle.OracleFactory;
import de.uni_leipzig.simba.mapper.SetConstraintsMapper;
import de.uni_leipzig.simba.mapper.SetConstraintsMapperFactory;

/**
 * Implementation of our custom FitnessFunction.
 * As we're using the <code>DeltaFitnessEvaluator</code> higher values mean the
 * individual is lesser fit.
 * @author Klaus Lyko
 *
 */
public class ExpressionFitnessFunction extends GPFitnessFunction {

	static Logger logger = Logger.getLogger("LIMES");
	private final ExpressionConfiguration m_config;
	private ConfigReader cR;
	private SetConstraintsMapper sCM;
	private Mapping optimalMapping;

	public ExpressionFitnessFunction(ExpressionConfiguration a_config) {
		super();
		m_config = a_config;
		
		// read config
		cR = new ConfigReader();
		cR.validateAndRead(m_config.configFile);
		//get Chaches and filter
		HybridCache sC = HybridCache.getData(cR.sourceInfo);
		HybridCache tC = HybridCache.getData(cR.targetInfo);
		Filter f = new LinearFilter();
		
		// get Mapper
		sCM = SetConstraintsMapperFactory.getMapper( "filterbased", cR.sourceInfo, cR.targetInfo, 
				sC, tC, f, cR.granularity);
		//logger.info("Expression Logger for executionPlan "+cR.executionPlan);
		// get optimalMapping
		String file = "C:/Users/Lyko/Desktop/Ba Arbeit/DBLP-ACM/DBLP-ACM/DBLP-ACM_perfectMapping.csv";
		Oracle o = OracleFactory.getOracle(file, "csv", "simple");
		optimalMapping = o.getMapping();

		
	}
	
	@Override
	protected double evaluate(IGPProgram a_subject) {
		return calculateRawFitness(a_subject);
	}
	
	private double calculateRawFitness(IGPProgram p) {	
		
		// get actual Mapping
		Object[] args = {};
		ProgramChromosome pc = p.getChromosome(0);
		Mapping actualMapping = new Mapping();
		try {
			/* SimilartyCommands are checked before execution, if they try to compare
			 * values not part of the property Mapping done before evolution process
			 * this will throw a IllegalStateException.
			 */
			String expr = (String) pc.getNode(0).execute_object(pc, 0, args);
			double accThreshold = p.getChromosome(1).execute_double(args);
			logger.info("Getting Mapping for expression "+expr+" at accThres "+accThreshold);
			actualMapping = getMapping(expr, accThreshold);
			
		}
		catch(IllegalStateException e) {
			/*
			 * If a SimilarityCommand compares properties not part of the property mapping
			 * we will return a bad fitness value (currently a big one).
			 */
			//return optimalMapping.size();
			return 10d;
		}
		
		
		
		// compare actualMap to optimalMap
		PRFComputer prfC = new PRFComputer();
		// f-score is a value between 0 and 1. whereas 1 is the optimal value.
		//return Math.abs(optimalMapping.size()-actualMapping.size());
		
		//double fScore = prfC.computeFScore(actualMapping, optimalMapping);
		//double prec = prfC.computePrecision(actualMapping, optimalMapping);
		double recall = prfC.computeRecall(actualMapping, optimalMapping);
		double res = recall;
		if(Double.isNaN(res)) {
			logger.info("res was NaN");
			return 10d;			
		}
				
		return 1.0d-res;
				
		// return Math.abs(1.0d*(30-p.getChromosome(0).getSize(0)));
	}
	
	/**
	 * Just for testing.	 * 
	 * @param p The GPProgram to be printed to Std.out.
	 */
	private String printSolution(IGPProgram p) {
		Object[] args = {};
		ProgramChromosome pc = p.getChromosome(0);
		String expr =(String) pc.getNode(0).execute_object(pc, 0, args);
		expr += "\n\t" + calculateRawFitness(p);
		return expr;		
	}
	
	private Mapping getMapping(String expression, double accThreshold) {
/*		// read config
		ConfigReader cR = new ConfigReader();
		cR.validateAndRead(m_config.configFile);
		//get Chaches and filter
		HybridCache sC = HybridCache.getData(cR.sourceInfo);
		HybridCache tC = HybridCache.getData(cR.targetInfo);
		Filter f = new LinearFilter();
		// get Mapping
		SetConstraintsMapper sCM = SetConstraintsMapperFactory.getMapper(cR.executionPlan, cR.sourceInfo, cR.targetInfo, 
				sC, tC, f, cR.granularity);

*/		
		
		Mapping m = sCM.getLinks(expression, accThreshold);
		return m;
	}
}
