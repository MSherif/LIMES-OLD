package de.uni_leipzig.simba.genetics.core;

import java.util.ArrayList;
import java.util.List;

import org.jgap.InvalidConfigurationException;
import org.jgap.NaturalSelector;
import org.jgap.gp.impl.DeltaGPFitnessEvaluator;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.TournamentSelector;

import de.uni_leipzig.simba.data.Mapping;
import de.uni_leipzig.simba.io.ConfigReader;
import de.uni_leipzig.simba.io.KBInfo;
import de.uni_leipzig.simba.learning.query.PropertyMapper;


/**
 * Sets up the basic JGAP configurations. We will still need to set the population
 * size.
 * @author Klaus Lyko
 *
 */
public class ExpressionConfiguration extends GPConfiguration {

	public String configFile = "PublicationData.xml";
	/* holds information about the source */
	public KBInfo source;
	/* holds information about the target */
	public KBInfo target;
	/* holds property mapping */
	public Mapping properties = new Mapping();
	
	public ExpressionConfiguration() throws InvalidConfigurationException {
		super();
		setSelectionMethod(new TournamentSelector(2));
	    setGPFitnessEvaluator(new DeltaGPFitnessEvaluator());// the lower the better
	    setStrictProgramCreation(true);
	    setProgramCreationMaxTries(100);
	    setMinInitDepth(2);
	    setMaxInitDepth(13);
	    setCrossoverProb(0.3f); //0.9
	    setReproductionProb(0.7f); //0.1
	    setNewChromsPercent(0.25f); //0.4
	    setMutationProb(0.8f);
	    setMaxCrossoverDepth(45);
	    //setNodeValidator(new ExpressionNodeValidator());
	    this.setVerifyPrograms(true);
	    setFitnessFunction(new ExpressionFitnessFunction(this));
	}
	
	public ExpressionConfiguration(KBInfo sourceInfo, KBInfo targetInfo) throws InvalidConfigurationException {
		this();
		source = sourceInfo;
		target = targetInfo;
	}
	
	public ExpressionConfiguration(String pathToConfig) throws InvalidConfigurationException {
		this();
		configFile = pathToConfig;
		readConfig();
	}
	
	private void readConfig() {
		ConfigReader cR = new ConfigReader();
		cR.validateAndRead(configFile);
		source = cR.sourceInfo;
		target = cR.targetInfo;
	}
	
	/**
	 * Method to get the a Property Mapping first.
	 * @TODO implement.
	 */
	public void getPropertyMapping() {
		
	}
	
	/**
	 * For testing purposes just set up a property mapping manually.
	 */
	public void setUpTestCase() {
		int max = Math.max(source.properties.size(), target.properties.size());
		for(int i = 0; i<max; i++) {
			properties.add(source.properties.get(i), target.properties.get(i), 1.0d);
		}
	}
	
	public void setPropertyMapping(Mapping propertyMap) {
		properties=propertyMap;
	}
	
	/**
	 * Little helper function to retrieve plane property names.
	 * @param id Number of the property in the property List.
	 * @param discriminant String to differ between the two Linked Data Sources dubbed "source" and "target".
	 * @return name of the property with the given number.
	 */
	public String getPropertyName(String discriminant, int id) {
		String ret="";
		if(discriminant.equalsIgnoreCase("source"))
			ret = source.properties.get(id);
		else
			ret = target.properties.get(id);
		if (ret.contains(".")) {
			 if(ret.split("\\.").length == 2) {
	            ret= ret.split("\\.")[1];
			 }
		 }
		return ret;
	}
	
	/**
	 * Function to retrieve properties of the Linked Data sources dubbed source and target
	 * completed with specified the variable of the knowledge base to comply with the limes dtd.
	 * Variables have in most cases the form "?x", properties are the names of the property possibly starting
	 * with a namespace, e.g. "dc:title". But for a metric expression we have to combine both without the question mark:
	 * E.g. "x.dc:title".
	 * @param discriminant String "source" or "target" to differ between the both knowledge bases. 
	 * @param id Number of the property in the properties list in the according KBInfo.
	 * @return Combined String of variable and property.
	 */
	public String getExpressionProperty(String discriminant, int id) {
		String ret;
		if(discriminant.equalsIgnoreCase("source")) {
			ret = source.var;
			if(ret.startsWith("?") && ret.length()>=2)
				ret = ret.substring(1);
			ret += "."+getPropertyName(discriminant, id);
			return ret;
		}
		else {
			ret = target.var;
			if(ret.startsWith("?") && ret.length()>=2)
				ret = ret.substring(1);
			ret += "."+getPropertyName(discriminant, id);
			return ret;
		}
	}
}
