/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.query;

import de.uni_leipzig.simba.cache.Cache;
import de.uni_leipzig.simba.cache.MemoryCache;
import de.uni_leipzig.simba.io.KBInfo;
import de.uni_leipzig.simba.preprocessing.Preprocessor;
import java.io.*;
import java.util.ArrayList;
import org.apache.log4j.*;

/**
 *
 * @author ngonga
 */
public class CsvQueryModule implements QueryModule {

    private String SEP = ",";
    KBInfo kb;

    public CsvQueryModule(KBInfo kbinfo) {
        kb = kbinfo;
    }

        public void setSeparation(String s)
    {
        SEP = s;
    }

    /** Read a CSV file and write the content in a cache. The first line is 
     * the name of the properties.
     * @param c Cache in which the content is to be written
     */
    public void fillCache(Cache c) {
        Logger logger = Logger.getLogger("LIMES");
        try {
            // in case a CSV is use, endpoint is the file to read
            BufferedReader reader = new BufferedReader(new FileReader(kb.endpoint));
            String s = reader.readLine();
            String split[];
            //first read name of properties. URI = first column
            if (s != null) {
                ArrayList<String> properties = new ArrayList<String>();
                //split first line
                split = s.split(SEP);
                for(int i=0; i< split.length; i++)
                    properties.add(split[i]);
                logger.info("Properties = "+properties);
                logger.info("KB Properties = "+kb.properties);
                //read remaining lines

                s = reader.readLine();
                String value;
                while (s != null) {
                    split = s.split(SEP);
                    for(int i=0; i<kb.properties.size(); i++)
                    {
                        value = split[properties.indexOf(kb.properties.get(i))];
                        value = Preprocessor.process(value, kb.functions.get(kb.properties.get(i)));
                        if(properties.indexOf(kb.properties.get(i))>=0)
                        c.addTriple(split[0], kb.properties.get(i),
                                value);
                    }
                    s = reader.readLine();
                }
            }
            else
            {
                logger.warn("Input file "+kb.endpoint+" was empty or faulty");
            }
            reader.close();
            logger.info("Retrieved "+c.size()+" statements");
        } catch (Exception e) {
            logger.fatal("Exception:" + e.getMessage());
            e.printStackTrace();
        }
    }
}
