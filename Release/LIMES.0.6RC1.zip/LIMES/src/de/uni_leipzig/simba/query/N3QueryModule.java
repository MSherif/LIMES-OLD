/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.query;

import de.uni_leipzig.simba.cache.Cache;
import de.uni_leipzig.simba.cache.MemoryCache;
import de.uni_leipzig.simba.io.KBInfo;
import de.uni_leipzig.simba.preprocessing.Preprocessor;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.log4j.Logger;

/**
 *
 * @author ngonga
 */
public class N3QueryModule implements QueryModule {

    KBInfo kb;

    public void fillCache(Cache c) {
        //contains all prefixes found in the N3 file
        HashMap<String, String> prefixes = new HashMap<String, String>();

        Logger logger = Logger.getLogger("LIMES");
        try {
            // in case a N3 is used, endpoint is the file to read
            BufferedReader reader = new BufferedReader(new FileReader(kb.endpoint));
            String s = reader.readLine();
            String split[];
            //first read name of properties. URI = first column
            if (s != null) {
                //split lines and check for prefixes
                s = reader.readLine();
                String subject, predicate, object;
                while (s != null) {
                    s = s.trim();
                    if (s.length() > 0) {
                        //process prefixes
                        if (s.startsWith("@prefix")) {
                            split = s.split(" ");
                            //write the prefixes in the knowledge base
                            //assume consistency
                            kb.prefixes.put(split[1], split[2]);
                        } //we assume this is a triple
                        else {
                            split = s.split(" ");
                            subject = split[0].replace("<", "").replace(">", "");
                            predicate = split[1].replace("<", "").replace(">", "");
                            object = Preprocessor.process(split[2].replace("<", "").replace(">", ""), 
                                    kb.functions.get(predicate));
                                    c.addTriple(subject, predicate, object);
                        }
                    }
                    s = reader.readLine();
                }
            } else {
                logger.warn("Input file " + kb.endpoint + " was empty or faulty");
            }
            reader.close();
            logger.info("Retrieved " + c.size() + " statements");
        } catch (Exception e) {
            logger.fatal("Exception:" + e.getMessage());
            e.printStackTrace();            
        }
    }

    public N3QueryModule(KBInfo kbinfo) {
        kb = kbinfo;
    }
    
    public static void main(String args[])
    {
        KBInfo k = new KBInfo();
        k.endpoint = "D:/Work/Java/LIMES/bf_drugbank_reviewme.nt";
        MemoryCache c = new MemoryCache();
        N3QueryModule qm = new N3QueryModule(k);
        qm.fillCache(c);
        System.out.println(c);        
    }
}
