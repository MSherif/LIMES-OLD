/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.uni_leipzig.simba.query;

import de.uni_leipzig.simba.io.KBInfo;
import org.apache.log4j.Logger;

/**
 *
 * @author ngonga
 */
public class QueryModuleFactory {

    static Logger logger = Logger.getLogger("LIMES");
    public static QueryModule getQueryModule(String name, KBInfo kbinfo)
    {
        logger.info("Generating "+name+" reader");
        if(name.toLowerCase().startsWith("csv")) return new CsvQueryModule(kbinfo);
        else if(name.toLowerCase().startsWith("n3")) return new N3QueryModule(kbinfo);
        else if(name.toLowerCase().startsWith("vector")) return new VectorQueryModule(kbinfo);
        //default
        return new SparqlQueryModule(kbinfo);
    }
}
