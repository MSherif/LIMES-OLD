/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.uni_leipzig.simba.mapper;

import de.uni_leipzig.simba.cache.Cache;
import de.uni_leipzig.simba.data.Mapping;

/**
 *
 * @author ngonga
 */
public interface AtomicMapper {
    Mapping getMapping(Cache source, Cache target, String sourceVar, String targetVar, String expression, double threshold);
}
