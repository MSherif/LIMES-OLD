/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.uni_leipzig.simba.evaluation;

import de.uni_leipzig.simba.data.Mapping;

/**
 *
 * @author ngonga
 */
public class PRFComputer {

    public double getOverlap(Mapping m, Mapping reference)
    {
        double counter = 0;
        for(String key: m.map.keySet())
        {
            for(String value : m.map.get(key).keySet())
            {
                if(reference.map.containsKey(key))
                {
                    if(reference.map.get(key).containsKey(value))
                    {
                        counter++;
                    }
                }
            }
        }
        return counter;
    }

    public double computePrecision(Mapping m, Mapping reference)
    {
        return getOverlap(m, reference)/(double)m.size();
    }

    public double computeRecall(Mapping m, Mapping reference)
    {
        return getOverlap(m, reference)/(double)reference.size();
    }

    public double computeFScore(Mapping m, Mapping reference)
    {
        double overlap = getOverlap(m, reference);
        return 2*(overlap/m.size())*(overlap/reference.size())/((overlap/m.size())+(overlap/reference.size()));
    }

}
