/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.uni_leipzig.simba.learning.learner;

/**
 *
 * @author ngonga
 */
public interface Configuration {
    public String getExpression();
}
