/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.learning.query;

import java.util.HashMap;
import org.apache.log4j.Logger;
import com.hp.hpl.jena.query.*;
import de.uni_leipzig.simba.data.Mapping;
import de.uni_leipzig.simba.learning.stablematching.HospitalResidents;
import java.util.TreeSet;

/**
 *
 * @author ngonga
 */
public class PropertyMapper {

    public int LIMIT = 1000;
    static Logger logger = Logger.getLogger("LIMES");
    public int MINSIM = 1;

    /** Applies stable matching to determine the best possible mapping of 
     * properties from two endpoints
     * @param endpoint1 Source endpoint
     * @param endpoint2 Target endpoint
     * @param classExpression1 Source class expression
     * @param classExpression2 Target class expression
     * @return 
     */
    public Mapping getPropertyMapping(String endpoint1,
            String endpoint2, String classExpression1, String classExpression2) {
        Mapping m = getMappingProperties(endpoint1, endpoint2, classExpression1, classExpression2);
        HospitalResidents hr = new HospitalResidents();
        m = hr.getMatching(m);
        Mapping copy = new Mapping();
        //clean from nonsense, i.e., maps of weight 0
        for (String s : m.map.keySet()) {
            for (String t : m.map.get(s).keySet()) {
                if (m.getSimilarity(s, t) >= MINSIM) {
                    copy.add(s, t, m.getSimilarity(s, t));
                }
            }
        }
        return copy;
    }

    /** Computes the mapping of property from enpoint1 to endpoint2 by using the
     * restriction classExpression 1 and classExpression2
     *
     */
    public Mapping getMappingProperties(String endpoint1,
            String endpoint2, String classExpression1, String classExpression2) {

        logger.info("Getting mapping from " + classExpression1 + " to " + classExpression2);
        Mapping m2 = getMonoDirectionalMap(endpoint1, endpoint2, classExpression1, classExpression2);
        logger.info("Getting mapping from " + classExpression2 + " to " + classExpression1);
        Mapping m1 = getMonoDirectionalMap(endpoint2, endpoint1, classExpression2, classExpression1);
        //logger.info(m2);
        logger.info("Merging the mappings...");
        double sim1, sim2;
        for (String key : m1.map.keySet()) {
            for (String value : m1.map.get(key).keySet()) {
                sim2 = m2.getSimilarity(value, key);
                sim1 = m1.getSimilarity(key, value);
                m2.add(value, key, sim1 + sim2);
            }
        }
        logger.info("Property mapping is \n" + m2);
        return m2;
    }

    public Mapping getMonoDirectionalMap(String endpoint1,
            String endpoint2, String classExpression1, String classExpression2) {


        HashMap<String, TreeSet<String>> propertyValueMap =
                new HashMap<String, TreeSet<String>>();
        Mapping propertyToProperty = new Mapping();

        //get property values from first knowledge base
        String query = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> \n"
                + "SELECT ?s ?p ?o \n"
                + "WHERE { ?s rdf:type <" + classExpression1 + "> . \n"
                + "?s ?p ?o . "
                //+ "FILTER(lang(?o) = \"en\"). "
                + //"FILTER REGEX (str(?o), \"^^xsd:string\" " +
                "\n}";
        if (LIMIT > 0) {
            query = query + " LIMIT " + LIMIT;
        }

        logger.info("Query:\n" + query);
        Query sparqlQuery = QueryFactory.create(query);
        QueryExecution qexec;
        qexec = QueryExecutionFactory.sparqlService(endpoint1, sparqlQuery);
        ResultSet results = qexec.execSelect();

        // first get LIMIT instances from
        String s, p, o;
        while (results.hasNext()) {
            QuerySolution soln = results.nextSolution();
            {
                try {
                    s = soln.get("s").toString();
                    p = soln.get("p").toString();
                    o = soln.get("o").toString();
                    //gets rid of all numeric properties
                    if (!isNumeric(o)) {
                        if (!propertyValueMap.containsKey(p)) {
                            propertyValueMap.put(p, new TreeSet<String>());
                        }
                        propertyValueMap.get(p).add(o);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        //logger.info("Got " + instanceToClassMap.size() + " classes");
        //logger.info(instanceToClassMap);
        //logger.info(instanceToInstanceMap);
        double sim;
        for (String property : propertyValueMap.keySet()) {

            for (String object : propertyValueMap.get(property)) {
                object = object.split("@")[0];
                if (!object.contains("\\") && !object.contains("\n") && !object.contains("\"")) {
                    //System.out.println(object);
                    query = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> \n"+
                            "SELECT ?p " +
                            "WHERE { ?s rdf:type <" + classExpression2 + "> . "+
                            "?s ?p \"" + object.replaceAll(" ", "_") + "\"}";
                    //logger.info(query);
                    sparqlQuery = QueryFactory.create(query);
                    qexec = QueryExecutionFactory.sparqlService(endpoint2, sparqlQuery);
                    results = qexec.execSelect();
                    QuerySolution soln;
                    while (results.hasNext()) {
                        soln = results.nextSolution();
                        {
                            try {
                                p = soln.get("p").toString();
                                sim = propertyToProperty.getSimilarity(property, p);
                                if (sim > 0) {
                                    propertyToProperty.map.get(property).put(p, sim + 1);
                                } else {
                                    propertyToProperty.add(property, p, 1.0);
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }

        //logger.info(classToClassMapping.map);
        return propertyToProperty;
    }

    public static void main(String args[]) {
        PropertyMapper pm = new PropertyMapper();
        Mapping m = pm.getMappingProperties("http://dbpedia.aksw.org:8899/sparql",
                "http://www4.wiwiss.fu-berlin.de/drugbank/sparql",
                "http://dbpedia.org/ontology/Drug",
                "http://www4.wiwiss.fu-berlin.de/drugbank/vocab/resource/class/Offer");
        System.out.println("Mapping =" + m);
        HospitalResidents hr = new HospitalResidents();
        System.out.println("Mapping =" + hr.getMatching(m));
    }

    /** Test whether the input string is numeric
     *
     * @param input String to test
     * @return True is numeric, else false
     */
    public static boolean isNumeric(String input) {
        if(input.contains("^^"))
            input = input.split("^^")[0];
        if(input.contains("%"))
            input = input.split("\\%")[0];
        try {
            Double.parseDouble(input);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
