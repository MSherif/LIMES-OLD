package de.uni_leipzig.simba.learning.oracle.mappingreader;

import java.io.BufferedReader;
import java.io.FileReader;

import de.uni_leipzig.simba.data.Mapping;

public class CSVMappingReader implements MappingReader {

    private String SEP = ",";

    @Override
    public Mapping getMapping(String filePath) {
        Mapping result = new Mapping();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String s = reader.readLine();
            String split[];
            //first read name of properties. URI = first column
            while (s != null) {
                //split first line
                split = s.split(SEP);
                 result.add(split[0], split[1], 1.0);                
                s = reader.readLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public void setSeparator(String s) {
        SEP = s;
    }

    public static void main(String args[]) {
        CSVMappingReader reader = new CSVMappingReader();
        Mapping m = reader.getMapping("D:/Work/Data/DBvsLIMES/DBLP-ACM/DBLP-ACM_perfectMapping.csv");
        System.out.println(m);
    }

    public String getType() {
        if(SEP.equalsIgnoreCase("\t")) return "TAB";
        return "CSV";
    }
}
