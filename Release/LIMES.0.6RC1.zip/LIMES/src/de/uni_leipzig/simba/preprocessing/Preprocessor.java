/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.preprocessing;

/**
 *
 * @author ngonga
 */
public class Preprocessor {

    public static String process(String entry, String functionChain) {
        String result = entry.split("\\^")[0];
        if (functionChain != null) {
            if (!functionChain.equals("")) {
                {
                    String split[] = functionChain.split("->");
                    for (int i = 0; i < split.length; i++) {
                        result = atomicProcess(result, split[i]);
                    }
                }
            }
        }
        //System.out.println(entry + " -> " + result);
        return result;
    }

    public static String atomicProcess(String entry, String function) {
        if (function.length() < 2) {
            return entry;
        }
        //remove unneeded xsd information        
        function = function.toLowerCase();
        if (function.startsWith("lowercase")) {
            return entry.toLowerCase();
        }
        if (function.startsWith("uppercase")) {
            return entry.toUpperCase();
        }
        if (function.startsWith("replace")) {
            String replaced = function.substring(8, function.indexOf(","));
            String replacee = function.substring(function.indexOf(",") + 1, function.indexOf(")"));
            System.out.println(replaced + ">, <" + replacee);
            return entry.replaceAll(replaced, replacee);
        }
        if (function.startsWith("nolang")) {
            if (entry.contains("@")) {
                return entry.substring(0, entry.lastIndexOf("@"));
            } else {
                return entry;
            }
        }
        if (function.startsWith("cleaniri")) {
            if (entry.contains("/")) {
                return entry.substring(entry.lastIndexOf("/")+1);
            } else {
                return entry;
            }
        }
        if (function.startsWith("number")) {
            //get rid of the type information
            String value = entry.replaceAll("[^0-9,.]", "");
            if (value.length() == 0) {
                return 0 + "";
            } else {
                try {
                    Double.parseDouble(value);
                } catch (Exception e) {
                    return 0 + "";
                }
            }
            return value;
        }
        if (function.startsWith("celsius")) {
            //get rid of the type information
            double value = Double.parseDouble(atomicProcess(entry, "number"));
            double result = 32+value*9/5;
            return result+"";
        }
        if (function.startsWith("fahrenheit")) {
            //get rid of the type information
            double value = Double.parseDouble(atomicProcess(entry, "number"));
            double result = (value-32)*5/9;
            return result+"";
        }
        if (function.startsWith("date")) {
            return entry.replaceAll("[^0-9,.-]", "");
        } else {
            return entry;
        }
    }

    public static void main(String args[]) {
        System.out.println(process("http://dbpedia.org/resource/Butter", "cleaniri"));
    }
}
