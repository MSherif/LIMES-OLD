/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.measures;

import de.uni_leipzig.simba.measures.space.EuclideanMetric;
import de.uni_leipzig.simba.measures.space.GeoDistance;
import de.uni_leipzig.simba.measures.string.CosineMeasure;
import de.uni_leipzig.simba.measures.string.TrigramMeasure;
import de.uni_leipzig.simba.measures.string.JaccardMeasure;
import de.uni_leipzig.simba.measures.string.Levenshtein;

/**
 *
 * @author ngonga
 */
public class MeasureFactory {

    public static Measure getMeasure(String name) {
        if (name.toLowerCase().startsWith("cosine")) {
            return new CosineMeasure();
        } else if (name.toLowerCase().startsWith("jaccard")) {
            return new JaccardMeasure();
        } else if (name.toLowerCase().startsWith("euclidean")) {
            return new EuclideanMetric();
        }
        else if (name.toLowerCase().startsWith("levens")) {
            return new Levenshtein();
        }
        else {
            return new TrigramMeasure();
        }
    }

    /** Returns measures of a particular type. If measure with name "name" and type
     * "type" is not found, the default measure for the given type is returned, e.g.,
     * trigram similarity for strings. To get the defaukt measure of a given type,
     * simply use getMeasure("", type).
     * @param name Name of the measure
     * @param type Type of the measure
     * @return Similarity measure of the given type
     */
    public static Measure getMeasure(String name, String type) {
        if (type.equals("string")) {
            if (name.toLowerCase().startsWith("cosine")) {
                return new CosineMeasure();
            } else if (name.toLowerCase().startsWith("jaccard")) {
                return new JaccardMeasure();
            }
            //default
                return new TrigramMeasure();
            
        } else if (type.equals("spatial")) {
            if (name.toLowerCase().startsWith("geo")) {
                return new GeoDistance();
            }
            else if (name.toLowerCase().startsWith("euclidean")) {
                return new EuclideanMetric();
            }
            //default
            return new EuclideanMetric();
        }
        //default of all
        return new TrigramMeasure();
    }
}
