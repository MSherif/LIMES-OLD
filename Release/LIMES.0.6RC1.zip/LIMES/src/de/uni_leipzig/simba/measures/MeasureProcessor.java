/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.measures;

import de.uni_leipzig.simba.cache.Cache;
import de.uni_leipzig.simba.cache.MemoryCache;
import de.uni_leipzig.simba.data.Instance;
import de.uni_leipzig.simba.controller.Parser;
import org.apache.log4j.Logger;

/**
 *
 * @author ngonga
 */
public class MeasureProcessor {
    static Logger logger = Logger.getLogger("LIMES");

    public static double getSimilarity(Instance sourceInstance, Instance targetInstance, String expression, String sourceVar, String targetVar) {
        Parser p = new Parser(expression, 0);

        if (p.isAtomic()) {
            System.out.println("ATOMIC");
            Measure measure = MeasureFactory.getMeasure(p.getOperation());
            System.out.println("Measure = "+measure.getName());
            //get property name
            //0. get properties
            //get property labels
            //get first property label
                    String property1 = null, property2 = null;
        //get property labels

        //get first property label
        String term1 = "?"+p.getTerm1();
        String term2 = "?"+p.getTerm2();
        String split[];
        String var;

         String property="";
        if (term1.contains(".")) {
            split = term1.split("\\.");
            var = split[0];
            property = split[1];
            if(split.length >= 2)
            {
                for(int i=2;i<split.length; i++)
                property = property + "." +split[i];
            }
            if (var.equals(sourceVar)) {
                //property1 = split[1];
                property1 = property;
            } else {
                //property2 = split[1];
                property2 = property;
            }
        } else {
            property1 = term1;
        }

        //get second property label
        if (term2.contains(".")) {
            split = term2.split("\\.");
            var = split[0];
            property = split[1];
            if(split.length >= 2)
            {
                for(int i=2;i<split.length; i++)
                property = property + "." +split[i];
            }
            if (var.equals(sourceVar)) {
                //property1 = split[1];
                property1 = property;
            } else {
                //property2 = split[1];
                property2 = property;
            }
        } else {
            property2 = term2;
        }
         
        //if no properties then terminate
        if (property1 == null || property2 == null) {
            logger.fatal("Property values could not be read. Exiting");
            System.exit(1);
        }
            return measure.getSimilarity(sourceInstance, targetInstance, property1, property2);
        }

        else
        {
            //System.out.println("Operation = "+p.op);
            if(p.op.equalsIgnoreCase("MAX"))
                return Math.max(getSimilarity(sourceInstance, targetInstance, p.getTerm1(), sourceVar, targetVar),
                        getSimilarity(sourceInstance, targetInstance, p.getTerm2(), sourceVar, targetVar));
            if(p.op.equalsIgnoreCase("MIN"))
                return Math.min(getSimilarity(sourceInstance, targetInstance, p.getTerm1(), sourceVar, targetVar),
                        getSimilarity(sourceInstance, targetInstance, p.getTerm2(), sourceVar, targetVar));
            if(p.op.equalsIgnoreCase("ADD"))
            {
                System.out.println(p.coef1);
                System.out.println(p.coef2);
                return p.coef1*getSimilarity(sourceInstance, targetInstance, p.getTerm1(), sourceVar, targetVar)
                        + p.coef2*getSimilarity(sourceInstance, targetInstance, p.getTerm2(), sourceVar, targetVar);
            }
            else
            {
                logger.fatal("Unparseable expression "+expression+". Exiting.");
                System.exit(1);
            }
        }
        return 0;
    }


    public static void main(String args[])
    {
        Cache source = new MemoryCache();
        Cache target = new MemoryCache();
        source.addTriple("S1", "pub", "test");
        source.addTriple("S1", "conf", "conf one");
        source.addTriple("S2", "pub", "test2");
        source.addTriple("S2", "conf", "conf2");

        target.addTriple("S1", "pub", "test");
        target.addTriple("S1", "conf", "conf one");
        target.addTriple("S3", "pub", "test1");
        target.addTriple("S3", "conf", "conf three");

        System.out.println(MeasureProcessor.getSimilarity(source.getInstance("S1"), target.getInstance("S3"), 
                "ADD(0.5*trigram(x.conf, y.conf),0.5*cosine(y.conf, x.conf))", "?x", "?y"));
        
    }
}
