/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.io.serializer;

import de.uni_leipzig.simba.data.Mapping;
import de.uni_leipzig.simba.io.Serializer;
import java.util.HashMap;
import java.util.Iterator;
import java.io.*;
import java.util.TreeSet;
import org.apache.log4j.*;

/**
 * Implements a simple serializer that generates NTriple files.
 * @author ngonga
 */
public class SimpleN3Serializer implements Serializer {

    PrintWriter writer;
    Logger logger = Logger.getLogger("LIMES");
    TreeSet<String> statements;

    public SimpleN3Serializer() {
        statements = new TreeSet<String>();
    }

    public void addStatement(String subject, String predicate, String object, double similarity)
    {
        statements.add("<" + subject + "> " + predicate + " <" + object + "> .");
    }

    public void flush()
    {
        try {
            for(String s: statements)
                writer.println(s);
            statements = new TreeSet<String>();
        } catch (Exception e) {
            logger.warn("Error writing");
        }
    }

    public void writeToFile(HashMap<String, String> prefixes, Mapping m, String file) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void printPrefixes(HashMap<String, String> prefixes) {
        try {
            Iterator<String> iter = prefixes.keySet().iterator();
            String prefix;
            while (iter.hasNext()) {
                prefix = iter.next();
                writer.println("@prefix "+prefix+": <"+prefixes.get(prefix)+"> .");
            }
        } catch (Exception e) {
            logger.warn("Error writing");
        }
    }

    public void printStatement(String subject, String predicate, String object, double similarity) {
        try {
            writer.println("<" + subject + "> " + predicate + " <" + object + "> .");
        } catch (Exception e) {
            logger.warn("Error writing");
        }
    }

    public boolean close() {
        try {
            if(statements.size() > 0)
            {
                for(String s : statements)
                    writer.println(s);
            }
            writer.close();
        } catch (Exception e) {
            logger.warn("Error closing PrintWriter");
            logger.warn(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean open(String file) {
        try {
            writer = new PrintWriter(new BufferedWriter(new FileWriter(file)));
        } catch (Exception e) {
            logger.warn("Error creating PrintWriter");
            logger.warn(e.getMessage());
            return false;
        }
        return true;
    }

    public String getName()
    {
        return "N3Serializer";
    }
}
