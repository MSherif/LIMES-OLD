/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.uni_leipzig.simba.io;

import de.uni_leipzig.simba.io.serializer.SimpleN3Serializer;
import de.uni_leipzig.simba.io.serializer.TabSeparatedSerializer;
import org.apache.log4j.Logger;

/**
 *
 * @author ngonga
 */
public class SerializerFactory {
    public static Serializer getSerializer(String name)
    {
        Logger logger = Logger.getLogger("LIMES");
        logger.info("Getting serializer with name "+name);
        if(name==null) return new SimpleN3Serializer();
        if(name.toLowerCase().trim().startsWith("tab")) return new TabSeparatedSerializer();
        else return new SimpleN3Serializer();
    }
}
