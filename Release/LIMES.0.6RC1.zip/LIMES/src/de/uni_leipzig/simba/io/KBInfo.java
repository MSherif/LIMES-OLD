/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.io;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Contains the infos necessary to access a knowledge base
 * @author ngonga
 */
public class KBInfo {

    public String id;
    public String endpoint;
    public String graph;
    public String var;
    // properties contain the list of properties whose values will be used during
    // the mapping process
    public List<String> properties;
    // restrictions specify the type of instances to be taken into consideration
    // while mapping
    public ArrayList<String> restrictions;
    public HashMap<String, String> functions;
    public HashMap<String, String> prefixes;
    public int pageSize;
    public String type; //can be sparql or csv, TODO add N3

    /**
     * Constructor
     */
    public KBInfo() {
        id = null;
        endpoint = null;
        graph = null;
        restrictions = new ArrayList<String>();
        properties = new ArrayList<String>();
        prefixes = new HashMap<String, String>();
        functions = new HashMap<String, String>();
        //-1 means query all at once
        pageSize = -1;
        type = "sparql"; //default value
    }

    /**
     * 
     * @return String representation of knowledge base info
     */
    @Override
    public String toString() {
        String s = "ID: " + id + "\n";
        s = s + "Prefixes: " + prefixes + "\n";
        s = s + "Endpoint: " + endpoint + "\n";
        s = s + "Graph: " + graph + "\n";
        s = s + "Restrictions: " + restrictions + "\n";
        s = s + "Properties: " + properties + "\n";
        s = s + "Page size: " + pageSize + "\n";
        s = s + "Type: " + type + "\n";
        return s;
    }

    /** Compute a hash code for the knowledge base encoded by this KBInfo.
     * Allow the hybrid cache to cache and retrieve the content of remote
     * knowledge bases on the hard drive for the user's convenience
     * @return The hash code of this KBInfo
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((endpoint == null) ? 0 : endpoint.hashCode());
        result = prime * result + ((graph == null) ? 0 : graph.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + pageSize;
        result = prime * result
                + ((prefixes == null) ? 0 : prefixes.hashCode());
        result = prime * result
                + ((properties == null) ? 0 : properties.hashCode());
        result = prime * result
                + ((restrictions == null) ? 0 : restrictions.hashCode());
        //result = prime * result + ((var == null) ? 0 : var.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        KBInfo other = (KBInfo) obj;
        if (endpoint == null) {
            if (other.endpoint != null) {
                return false;
            }
        } else if (!endpoint.equals(other.endpoint)) {
            return false;
        }
        if (graph == null) {
            if (other.graph != null) {
                return false;
            }
        } else if (!graph.equals(other.graph)) {
            return false;
        }
        if (id == null) {
            if (other.id != null) {
                return false;
            }
        } else if (!id.equals(other.id)) {
            return false;
        }
        if (pageSize != other.pageSize) {
            return false;
        }
        if (prefixes == null) {
            if (other.prefixes != null) {
                return false;
            }
        } else if (!prefixes.equals(other.prefixes)) {
            return false;
        }
        if (properties == null) {
            if (other.properties != null) {
                return false;
            }
        } else if (!properties.equals(other.properties)) {
            return false;
        }
        if (restrictions == null) {
            if (other.restrictions != null) {
                return false;
            }
        } else if (!restrictions.equals(other.restrictions)) {
            return false;
        }
        if (var == null) {
            if (other.var != null) {
                return false;
            }
        } else if (!var.equals(other.var)) {
            return false;
        }
        return true;
    }
}
