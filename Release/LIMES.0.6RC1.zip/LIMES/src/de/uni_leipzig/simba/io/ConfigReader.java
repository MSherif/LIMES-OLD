/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.io;

import java.io.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.util.HashMap;
import org.apache.log4j.*;

/**
 * Checks and extract data from LIMES linking specifications (i.e., configuration
 * files)
 * @author ngonga
 */
public class ConfigReader {

    public KBInfo sourceInfo;
    public KBInfo targetInfo;
    public String metricExpression;
    public String acceptanceRelation;
    public String verificationRelation;
    public double acceptanceThreshold;
    public String acceptanceFile;
    public double verificationThreshold;
    public String verificationFile;
    public int exemplars;
    public HashMap<String, String> prefixes;
    public String outputFormat;
    public String executionPlan;
    public int granularity;
    Logger logger;

    /** constructor
     * 
     */
    public ConfigReader() {
        logger = Logger.getLogger("LIMES");
        prefixes = new HashMap<String, String>();
        exemplars = -1;
        executionPlan = "simple";
        granularity = 2;
    }

    /** Returns true if the input complies to the LIMES DTD and contains everything needed.
     * NB: The path to the DTD must be specified in the input file
     * @param input The input XML file
     * @return true if parsing was successful, else false
     */
    public boolean validateAndRead(String input) {
        DtdChecker dtdChecker = new DtdChecker();
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            //make sure document is valid
            factory.setValidating(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setErrorHandler(dtdChecker);
            Document xmlDocument = builder.parse(new FileInputStream(input));

            if (dtdChecker.valid) {
                //now extract what we need
                logger.info("File is valid. Parsing ...");
                sourceInfo = new KBInfo();
                targetInfo = new KBInfo();
                //0. Prefixes
                NodeList list = xmlDocument.getElementsByTagName("PREFIX");
                NodeList children;
                String namespace = "", label = "";
                for (int i = 0; i < list.getLength(); i++) {
                    children = list.item(i).getChildNodes();
                    for (int j = 0; j < children.getLength(); j++) {
                        Node child = children.item(j);
                        if (child.getNodeName().equals("NAMESPACE")) {
                            namespace = getText(child);
                        } else if (child.getNodeName().equals("LABEL")) {
                            label = getText(child);
                        }
                    }
                    prefixes.put(label, namespace);
                }
                //1. Source information
                list = xmlDocument.getElementsByTagName("SOURCE");
                children = list.item(0).getChildNodes();
                String property, split[];
                for (int i = 0; i < children.getLength(); i++) {
                    Node child = children.item(i);
                    if (child.getNodeName().equals("ID")) {
                        sourceInfo.id = getText(child);
                    } else if (child.getNodeName().equals("ENDPOINT")) {
                        sourceInfo.endpoint = getText(child);
                    } else if (child.getNodeName().equals("GRAPH")) {
                        sourceInfo.graph = getText(child);
                    } else if (child.getNodeName().equals("RESTRICTION")) {
                        sourceInfo.restrictions.add(getText(child));
                    } else if (child.getNodeName().equals("PROPERTY")) {
                        property = getText(child);
                        split = property.split(" ");
                        sourceInfo.properties.add(split[0]);
                        if (split.length > 2) {
                            sourceInfo.functions.put(split[0], split[2]);
                        } else {
                            sourceInfo.functions.put(split[0], "");
                        }
                    } else if (child.getNodeName().equals("PAGESIZE")) {
                        sourceInfo.pageSize = Integer.parseInt(getText(child));
                    } else if (child.getNodeName().equals("VAR")) {
                        sourceInfo.var = getText(child);
                    } else if (child.getNodeName().equals("TYPE")) {
                        sourceInfo.type = getText(child).toLowerCase();
                    }
                }
                sourceInfo.prefixes = prefixes;
                logger.info("Source config\n" + sourceInfo.toString());
                
                //2. Target information
                list = xmlDocument.getElementsByTagName("TARGET");                
                children = list.item(0).getChildNodes();
                for (int i = 0; i < children.getLength(); i++) {
                    Node child = children.item(i);
                    if (child.getNodeName().equals("ID")) {
                        targetInfo.id = getText(child);
                    } else if (child.getNodeName().equals("ENDPOINT")) {
                        targetInfo.endpoint = getText(child);
                    } else if (child.getNodeName().equals("GRAPH")) {
                        targetInfo.graph = getText(child);
                    } else if (child.getNodeName().equals("RESTRICTION")) {
                        targetInfo.restrictions.add(getText(child));
                    } else if (child.getNodeName().equals("PROPERTY")) {
                        property = getText(child);
                        split = property.split(" ");
                        targetInfo.properties.add(split[0]);
                        if (split.length > 2) {
                            targetInfo.functions.put(split[0], split[2]);
                        } else {
                            targetInfo.functions.put(split[0], "");
                        }
                    } else if (child.getNodeName().equals("PAGESIZE")) {
                        targetInfo.pageSize = Integer.parseInt(getText(child));
                    } else if (child.getNodeName().equals("VAR")) {
                        targetInfo.var = getText(child);
                    } else if (child.getNodeName().equals("TYPE")) {
                        targetInfo.type = getText(child).toLowerCase();
                    }
                }
                targetInfo.prefixes = prefixes;
                logger.info("Target config\n" + targetInfo.toString());
                //3.METRIC
                list = xmlDocument.getElementsByTagName("METRIC");
                metricExpression = getText(list.item(0));
                logger.info("Metric used " + metricExpression);

                //4. Number of exemplars
                list = xmlDocument.getElementsByTagName("EXEMPLARS");
                if (list.getLength() > 0) {
                    exemplars = Integer.parseInt(getText(list.item(0)));
                    logger.info("Computation will be carried out with " + exemplars + " exemplars");
                }
                //5. ACCEPTANCE file and conditions
                list = xmlDocument.getElementsByTagName("ACCEPTANCE");
                children = list.item(0).getChildNodes();
                for (int i = 0; i < children.getLength(); i++) {
                    Node child = children.item(i);
                    if (child.getNodeName().equals("THRESHOLD")) {
                        acceptanceThreshold = Double.parseDouble(getText(child));
                    } else if (child.getNodeName().equals("FILE")) {
                        acceptanceFile = getText(child);
                    } else if (child.getNodeName().equals("RELATION")) {
                        acceptanceRelation = getText(child);
                    }
                }
                logger.info("Instances with similarity beyond " + acceptanceThreshold + " "
                        + "will be written in " + acceptanceFile + " and linked with " + acceptanceRelation);

                //6. VERIFICATION file and conditions
                list = xmlDocument.getElementsByTagName("REVIEW");
                children = list.item(0).getChildNodes();
                for (int i = 0; i < children.getLength(); i++) {
                    Node child = children.item(i);
                    if (child.getNodeName().equals("THRESHOLD")) {
                        verificationThreshold = Double.parseDouble(getText(child));
                    } else if (child.getNodeName().equals("FILE")) {
                        verificationFile = getText(child);
                    } else if (child.getNodeName().equals("RELATION")) {
                        verificationRelation = getText(child);
                    }
                }

                //7. EXECUTION plan
                if (list.getLength() > 0) {
                    list = xmlDocument.getElementsByTagName("EXECUTION");
                    children = list.item(0).getChildNodes();
                    executionPlan = getText(list.item(0));
                    logger.info("Linking will be carried out by using the " + executionPlan + " execution plan");
                } else {
                    logger.info("Linking will be carried out by using the default execution plan");
                }
                //8. TILING if necessary
                list = xmlDocument.getElementsByTagName("GRANULARITY");
                if (list.getLength() > 0) {
                    children = list.item(0).getChildNodes();
                    granularity = Integer.parseInt(getText(list.item(0)));
                    logger.info("Linking will be carried by using granularity " + granularity);
                } else {
                    logger.info("Linking will be carried by using the default granularity.");
                }

                //9. OUTPUT format
                list = xmlDocument.getElementsByTagName("OUTPUT");
                if (list.getLength() > 0) {
                    children = list.item(0).getChildNodes();
                    outputFormat = getText(list.item(0));
                    logger.info("Output will be written in " + outputFormat + " format.");
                } else {
                    logger.info("Output will be written in N3 format.");
                }
                logger.info("Instances with similarity between " + verificationThreshold + " "
                        + "and " + acceptanceThreshold + " will be written in " + verificationFile
                        + " and linked with " + verificationRelation);
            }
        } catch (Exception e) {
            logger.warn(e.getMessage());
            e.printStackTrace();
            logger.warn("Some values were not set. Crossing my fingers and using defaults.");
            //System.exit(1);
        }
        logger.info("File " + input + " is valid.");
        return dtdChecker.valid;
    }

    /** Returns the content of a node
     * 
     * @param node an item of the form <NODE> text </NODE>
     * @return The text between <NODE> and </NODE>
     */
    public static String getText(Node node) {

        // We need to retrieve the text from elements, entity
        // references, CDATA sections, and text nodes; but not
        // comments or processing instructions
        int type = node.getNodeType();
        if (type == Node.COMMENT_NODE
                || type == Node.PROCESSING_INSTRUCTION_NODE) {
            return "";
        }

        StringBuffer text = new StringBuffer();

        String value = node.getNodeValue();
        if (value != null) {
            text.append(value);
        }
        if (node.hasChildNodes()) {
            NodeList children = node.getChildNodes();
            for (int i = 0; i < children.getLength(); i++) {
                Node child = children.item(i);
                text.append(getText(child));
            }
        }

        return text.toString();

    }

    /**
     * Returns config of sourceInfo knowledge base
     * @return The KBInfo describing the sourceInfo knowledge base
     */
    public KBInfo getSourceInfo() {
        return sourceInfo;
    }

    /**
     * Returns config of targetInfo knowledge base
     * @return The KBInfo describing the targetInfo knowledge base
     */
    public KBInfo getTargetInfo() {
        return targetInfo;
    }
}
