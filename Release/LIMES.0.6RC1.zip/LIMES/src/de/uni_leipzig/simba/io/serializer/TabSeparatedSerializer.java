/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.uni_leipzig.simba.io.serializer;

/**
 *
 * @author ngonga
 */
public class TabSeparatedSerializer extends SimpleN3Serializer{
    public String SEPARATOR = "\t";

    @Override
    public void addStatement(String subject, String predicate, String object, double similarity)
    {
        statements.add(subject + SEPARATOR + object + SEPARATOR + similarity);
    }

    @Override
   public void printStatement(String subject, String predicate, String object, double similarity) {
        try {
            writer.println(subject + SEPARATOR + object + SEPARATOR + similarity);
        } catch (Exception e) {
            logger.warn("Error writing");
        }
    }

    public String getName()
    {
        return "TabSeparatedSerializer";
    }

}
