/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.uni_leipzig.simba.cache;

/**
 * Not yet implemented. Will be an elaborate cache for very large data sets
 * that do not fit in memory.
 * @author ngonga
 */
public class FileCache {

}
