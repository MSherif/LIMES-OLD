/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package de.uni_leipzig.simba.data;

/**
 * Enty for a mapping. Maps two uris with a similarity.
 * @author ngonga
 */
public class Triple {
    String targetUri;
    String sourceUri;
    float similarity;

    public Triple(String source, String target, float sim)
    {
        targetUri = target;
        sourceUri = source;
        similarity = sim;
    }

    @Override
    public String toString()
    {
        String s="";
        s = "<"+targetUri+">";
        s = s + " <"+sourceUri+"> ";
        s = s + similarity;
        return s;
    }
}
