/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.data;

import java.util.HashMap;
import java.util.Iterator;

/**
 * This class contains the mappings computed by an organizer. Each URI from
 * the second knowledge base is mapped to the URI of instances from the first
 * knowledge base and the corresponding similarity value. This is a help class
 * for further processing that simply stores the mapping results in memory.
 * It is important to notice that if (s, t, sim1) are already in the mapping and
 * (s, t, sim2) is added then the mapping will contain (s, t, max(sim1, sim2))
 * @author ngonga
 */
public class Mapping {

    public HashMap<String, HashMap<String, Double>> map;
    public int size;

    /** Constructor
     * 
     */
    public Mapping() {
        map = new HashMap<String, HashMap<String, Double>>();
        size = 0;
    }

    public int size() {
        return size;
    }

    /** Add a batch of similarities to the mapping
     *
     * @param uri A resource from the source knowledge base
     * @param instances Map containing uris from the target knowledge base and
     * their similarity to uri
     */
    public void add(String uri, HashMap<String, Double> instances) {
        if (!map.containsKey(uri)) {
            map.put(uri, instances);
        } else {
            Iterator<String> keyIter = instances.keySet().iterator();
            String mappingUri;
            while (keyIter.hasNext()) {
                mappingUri = keyIter.next();
                add(uri, mappingUri, instances.get(mappingUri));
                size++;
            }
        }
    }

    /** Add one entry to the mapping
     *
     * @param uri Uri in the source knowledge bases
     * @param mappingUri Mapping uri in the target knowledge base
     * @param similarity Similarity of uri and mappingUri
     */
    public void add(String uri, String mappingUri, double similarity) {
        if (map.containsKey(uri)) {
            //System.out.print("Found duplicate key " + uri);
            if (map.get(uri).containsKey(mappingUri)) {
                //System.out.println(" and value " + mappingUri);
                if (similarity > map.get(uri).get(mappingUri)) {
                    map.get(uri).put(mappingUri, similarity);
                }
            } else {
                map.get(uri).put(mappingUri, similarity);
            }
        } else {
            HashMap<String, Double> help = new HashMap<String, Double>();
            help.put(mappingUri, similarity);
            map.put(uri, help);
        }
        size++;
    }

    /** Checks whether the map contains a certain pair. If yes, its similarity
     * is returned. Else 0 is returned
     * @param sourceInstance Instance from the source knowledge base
     * @param targetInstance Instance from the target knowledge base
     * @return Similarity of the two instances according to the mapping
     */
    public double getSimilarity(String sourceInstance, String targetInstance) {
        if (map.containsKey(sourceInstance)) {
            if (map.get(sourceInstance).containsKey(targetInstance)) {
                return map.get(sourceInstance).get(targetInstance);
            }
        }
        return 0;
    }

    /** Checks whether a mapping contains a particular entry
     *
     * @param sourceInstance Key URI
     * @param targetInstance Value URI
     * @return True if mapping contains (key, value), else false.
     */
    public boolean contains(String sourceInstance, String targetInstance) {
        if (map.containsKey(sourceInstance)) {
            if (map.get(sourceInstance).containsKey(targetInstance)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        String s = "";
        for (String key : map.keySet()) {
            for (String value : map.get(key).keySet()) {
                s = s + "[" + key + " -> (" + value + "|" + map.get(key).get(value) + ")]\n";
            }
        }
        return s;
    }
}
