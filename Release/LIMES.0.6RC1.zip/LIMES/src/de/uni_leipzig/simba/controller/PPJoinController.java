/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.uni_leipzig.simba.controller;

import de.uni_leipzig.simba.cache.*;
import de.uni_leipzig.simba.data.Mapping;
import de.uni_leipzig.simba.filter.LinearFilter;
import de.uni_leipzig.simba.query.*;
import de.uni_leipzig.simba.io.*;
import de.uni_leipzig.simba.io.SerializerFactory;
import de.uni_leipzig.simba.mapper.SetConstraintsMapper;
import de.uni_leipzig.simba.mapper.SetConstraintsMapperFactory;
import de.uni_leipzig.simba.mapper.atomic.PPJoinPlusPlus;
import de.uni_leipzig.simba.mapper.atomic.PPJoinMapper;
import java.io.File;
import org.apache.log4j.*;

/**
 * Just for tests
 * @author ngonga
 */
public class PPJoinController {

    static Logger logger = Logger.getLogger("LIMES");

    public static void main(String args[]) {
        if (new File(args[0]).exists()) {
            run(args[0]);
        } else {
            logger.fatal("Input file " + args[0] + " does not exist.");
            System.exit(1);
        }
    }

    public static Mapping getMapping(String configFile) {

        long startTime = System.currentTimeMillis();
        //0. configure logger
        try {
            PatternLayout layout = new PatternLayout("%d{dd.MM.yyyy HH:mm:ss} %-5p [%t] %l: %m%n");
            FileAppender fileAppender = new FileAppender(layout, configFile.replaceAll(".xml", "") + ".log", false);
            fileAppender.setLayout(layout);
            logger.addAppender(fileAppender);
        } catch (Exception e) {
            logger.warn("Exception creating file appender.");
        }

        logger.setLevel(Level.DEBUG);

        //1. Read configFile
        ConfigReader cr = new ConfigReader();
        cr.validateAndRead(configFile);

        logger.info(cr.getSourceInfo());
        logger.info(cr.getTargetInfo());
        //System.exit(1);

        //2. Fill caches using the query module
        //2.1 First sourceInfo
        logger.info("Loading source data ...");
        HybridCache source = new HybridCache();
        source = HybridCache.getData(cr.getSourceInfo());

        //2.2 Then targetInfo
        logger.info("Loading target data ...");
        HybridCache target = new HybridCache();
        target = HybridCache.getData(cr.getTargetInfo());

        //logger.info("Content of sourceInfo\n"+sourceInfo);
        //logger.info("Content of targetInfo\n"+targetInfo);
        //System.exit(1);
        //2.3 Swap targetInfo and sourceInfo if targetInfo size is larger than sourceInfo size
        HybridCache help;
        KBInfo swap;
        String var;

        //No need for swapping anymore as operations are symmetric
        /*
        if (target.size() > source.size()) {
        logger.info("Swapping data sources as |T| > |S|");
        //swap data sources
        help = target;
        target = source;
        source = help;
        //swap configs
        swap = cr.sourceInfo;
        cr.sourceInfo = cr.targetInfo;
        cr.targetInfo = swap;
        }*/

        //Mapping mapping = (new PPJoinPlusPlus()).getMapping(sourceInfo, targetInfo, cr.sourceInfo.var, cr.targetInfo.var, cr.metricExpression, cr.verificationThreshold);
        SetConstraintsMapper mapper = SetConstraintsMapperFactory.getMapper(cr.executionPlan,
                cr.sourceInfo, cr.targetInfo, source, target, new LinearFilter(), cr.granularity);
        //cr.sourceInfo, cr.targetInfo, sourceInfo, targetInfo, new PPJoinMapper(), new LinearFilter());
        logger.info("Getting links ...");
        long time = System.currentTimeMillis();
        Mapping mapping = mapper.getLinks(cr.metricExpression, cr.verificationThreshold);
        logger.info("Got links in " + (System.currentTimeMillis() - time) + "ms.");
        //get Writer ready
        return mapping;
    }

    public static void run(String configFile) {

        long startTime = System.currentTimeMillis();
        //0. configure logger
        try {
            PatternLayout layout = new PatternLayout("%d{dd.MM.yyyy HH:mm:ss} %-5p [%t] %l: %m%n");
            FileAppender fileAppender = new FileAppender(layout, configFile.replaceAll(".xml", "") + ".log", false);
            fileAppender.setLayout(layout);
            logger.addAppender(fileAppender);
        } catch (Exception e) {
            logger.warn("Exception creating file appender.");
        }

        logger.setLevel(Level.DEBUG);

        //1. Read configFile
        ConfigReader cr = new ConfigReader();
        cr.validateAndRead(configFile);

        logger.info(cr.getSourceInfo());
        logger.info(cr.getTargetInfo());
        //System.exit(1);

        //2. Fill caches using the query module
        //2.1 First sourceInfo
        logger.info("Loading source data ...");
        HybridCache source = new HybridCache();
        source = HybridCache.getData(cr.getSourceInfo());

        //2.2 Then targetInfo
        logger.info("Loading target data ...");
        HybridCache target = new HybridCache();
        target = HybridCache.getData(cr.getTargetInfo());

        //logger.info("Content of sourceInfo\n"+sourceInfo);
        //logger.info("Content of targetInfo\n"+targetInfo);
        //System.exit(1);
        //2.3 Swap targetInfo and sourceInfo if targetInfo size is larger than sourceInfo size
        HybridCache help;
        KBInfo swap;
        String var;

        //No need for swapping anymore as operations are symmetric
        /*
        if (target.size() > source.size()) {
        logger.info("Swapping data sources as |T| > |S|");
        //swap data sources
        help = target;
        target = source;
        source = help;
        //swap configs
        swap = cr.sourceInfo;
        cr.sourceInfo = cr.targetInfo;
        cr.targetInfo = swap;
        }*/

        //Mapping mapping = (new PPJoinPlusPlus()).getMapping(sourceInfo, targetInfo, cr.sourceInfo.var, cr.targetInfo.var, cr.metricExpression, cr.verificationThreshold);
        SetConstraintsMapper mapper = SetConstraintsMapperFactory.getMapper(cr.executionPlan,
                cr.sourceInfo, cr.targetInfo, source, target, new LinearFilter(), cr.granularity);
        //cr.sourceInfo, cr.targetInfo, sourceInfo, targetInfo, new PPJoinMapper(), new LinearFilter());
        logger.info("Getting links ...");
        long time = System.currentTimeMillis();
        Mapping mapping = mapper.getLinks(cr.metricExpression, cr.verificationThreshold);
        logger.info("Got links in " + (System.currentTimeMillis() - time) + "ms.");
        //get Writer ready
        Serializer accepted = SerializerFactory.getSerializer(cr.outputFormat);
        Serializer toReview = SerializerFactory.getSerializer(cr.outputFormat);

        logger.info("Using " + accepted.getName() + " to serialize");
        accepted.open(cr.acceptanceFile);
        accepted.printPrefixes(cr.prefixes);
        toReview.open(cr.verificationFile);
        toReview.printPrefixes(cr.prefixes);

        //now write results
        int linkCounter = 0;
        int reviewCounter = 0;
        for (String key : mapping.map.keySet()) {
            for (String value : mapping.map.get(key).keySet()) {
                if (mapping.map.get(key).get(value) >= cr.acceptanceThreshold) {
                    linkCounter++;
                    accepted.printStatement(key, cr.acceptanceRelation, value, mapping.map.get(key).get(value));
                } else if (mapping.map.get(key).get(value) >= cr.verificationThreshold) {
                    reviewCounter++;
                    toReview.printStatement(key, cr.acceptanceRelation, value, mapping.map.get(key).get(value));
                }
            }
        }
        logger.info("Returned " + linkCounter + " links above acceptance threshold.");
        logger.info("Returned " + reviewCounter + " links to review.");
        //close writers
        accepted.close();
        toReview.close();

        logger.info("Mapping carried out in " + (System.currentTimeMillis() - startTime) / 1000.0 + " seconds");
        logger.info("Done.");
    }
}
