* dbpedia-dbpedia is a simple specification for deduplicating drugs and relies on simple preprocessing and renaming
* europeana-deduplication is a simple specification for deduplication and relies on basic preprocessing
* dblp-semanticwebresearcher is a simple specification for linking two knowledge bases and relies on basic preprocessing
* dbpedia-drugbank shows how to combine preprocessing and renaming for fusing property values
* dbpedia-drugbank-complex shows how do define complex specifications
 